
//String in Java 
class Main
{
    //create string 
    public static void main (String[]args){
    String first ="Java";
    String second ="python";
    String third ="JavaScript";
    //print String
    System.out.println("first");
    System.out.println("second");
    System.out.println("third");
    }
}
