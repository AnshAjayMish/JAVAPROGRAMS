//14.	Demonstrate using Instance/class  Variable in a Java Program by creating a simple public class

public class Prog14{
    int x=5;
    public static void main(String[] args) {
        Prog14 obj=new Prog14();
        System.out.print("The value assigned to instance variable is "+obj.x);
    }
}

