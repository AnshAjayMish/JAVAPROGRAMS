class ThreadCount extends Thread
{
  ThreadCount (String s)
  {
    super (s);
    System.out.println ("New thread created: " + s);
  }

  public void run ()
  {
    try
    {
      for (int i = 0; i < 10; i++)
	{
	  System.out.println ("New thread created");
	  Thread.sleep (1500);
	}
    } catch (InterruptedException e)
    {
      System.out.println ("Currently executing thread is interrupted");
    }
    System.out.println ("Currently executing thread run is terminated");
  }

  public static void main (String[]args)
  {
    ThreadCount thread = new ThreadCount ("Thread");
    thread.start ();
  }
}
