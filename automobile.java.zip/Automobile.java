public class Automobile {

    public void start() {
        System.out.println("Engine starts running");
    }

    public void stop() {
        System.out.println("Engine stops running");
    }

    public void seatings() {
        System.out.println("4 seating");
    }

    public static void main(String[] args) {
        Car car = new Car();
        car.start();
        car.NoOfTyres();
        car.fuel("Diesel");
        car.seatings();
        car.stop();

        Bike bike = new Bike();
        bike.start();
        bike.NoOfTyres();
        bike.fuel();
        bike.seatings();
        bike.stop();
    }
}

class Car extends Automobile {
    public void NoOfTyres() {
        System.out.println("There are 4 tyres");
    }

    public void fuel() {
        System.out.println("Petrol");
    }

    public void fuel(String fuel) {
        System.out.println("Also runs on " + fuel);
    }

    public void seatings() {
        System.out.println("4 seating");
    }
}

class Bike extends Automobile {
    public void NoOfTyres() {
        System.out.println("There are 2 tyres");
    }

    public void fuel() {
        System.out.println("Petrol");
    }
}
