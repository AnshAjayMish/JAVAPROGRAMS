/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class Data
{

  private String name;


  public String getName ()
  {
    return name;
  }


  public void setName (String name)
  {
    this.name = name;
  }
}

public class Main
{
  public static void main (String[]args)
  {

    Data d = new Data ();


      d.setName ("ANSH AJAY MISHRA");


    String dataName = d.getName ();


      System.out.println ("Name: " + dataName);
  }
}
