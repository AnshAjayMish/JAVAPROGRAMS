/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Average {

    public static double getAvg(int[][] a) {
        double total = 0;
        int rowCount = a.length;
        int colCount = a[0].length;

        for (int[] row : a) {
            for (int val : row) {
                System.out.println(val);
                total = total + val;
            }
        }

        return total / (rowCount * colCount);
    }

    public static void main(String[] args) {
        int[][] theArray = { { 80, 90, 70 }, { 20, 80, 75 } };
        System.out.println(getAvg(theArray));
    }
}
